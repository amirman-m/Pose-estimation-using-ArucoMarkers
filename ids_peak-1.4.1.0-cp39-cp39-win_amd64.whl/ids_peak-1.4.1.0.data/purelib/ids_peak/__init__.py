import os
import sys

if not "IDS_PEAK_GENERIC_SDK_PATH" in os.environ:
    raise RuntimeError("Required environment variable IDS_PEAK_GENERIC_SDK_PATH does not exist! Please (re)install peak or provide the SDK root path of peak (<peak-Installation-Directory>/sdk/) manually via environment variable IDS_PEAK_GENERIC_SDK_PATH!")

if (sys.version_info[0] < 3) or ((sys.version_info[0] == 3) and (sys.version_info[1] < 8)):
    os.environ["Path"] += os.pathsep + os.path.join(os.environ["IDS_PEAK_GENERIC_SDK_PATH"], "api", "lib", "x86_64")
else:
    os.add_dll_directory(os.path.join(os.environ["IDS_PEAK_GENERIC_SDK_PATH"], "api", "lib", "x86_64"))
    # Workaround for Conda Python 3.8 environments under Windows. Although Python changed the DLL search mechanism in Python 3.8, Windows Conda Python 3.8 environments still use the old mechanism...
    os.environ["Path"] += os.pathsep + os.path.join(os.environ["IDS_PEAK_GENERIC_SDK_PATH"], "api", "lib", "x86_64")
